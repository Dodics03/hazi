import os

print(os.listdir())

# Kérdések betöltése külső fájlból
import random


def load_questions(kerdesek):

    questions = []

    # with = biztonságos fájlkezelés
    with open(kerdesek, "r", encoding="utf-8") as file:

        for line in file:

            parts = line.strip().split(",")

            kerdes = {
                "varos": parts[0],
                "opciok": parts[1:5],
                "helyes": int(parts[5])
            }

            questions.append(kerdes)

    return questions


# Statisztika betöltése
def load_stats(statisztika):

    pontok = []

    try:
        with open(statisztika, "r") as file:

            for line in file:

                # pl.: "pont: 8"
                parts = line.strip().split(":")

                if len(parts) == 2:
                    pontok.append(int(parts[1]))

    except FileNotFoundError:
        pass

    return pontok


# Statisztika mentése
def save_stats(statisztika, pont):

    with open(statisztika, "a") as file:
        file.write(f"pont:{pont}\n")


# Játék
def play_game(questions):

    pont = 0

    # kiválaszt 10 kérdést véletlenszerűen
    kivalasztott = random.sample(questions, 10)

    for i, q in enumerate(kivalasztott):

        print("\n-------------------------")
        print(f"{i+1}. kérdés / 10")
        print("-------------------------")

        print("Melyik országban található az alábbi város?\n")

        # város külön sorban
        print(q["varos"])

        # opciók kiírása
        for j in range(4):
            print(f"{j+1}. {q['opciok'][j]}")

        # válasz bekérése
        while True:

            valasz = input("\nVálasz (1-4): ")

            if valasz in ["1", "2", "3", "4"]:
                valasz = int(valasz)
                break

            print("Kérem, adjon meg egy számot 1 és 4 között.")

        # válasz ellenőrzése
        if valasz == q["helyes"]:

            print("Helyes válasz!")
            pont += 1

        else:
            print("Helytelen válasz!")

        print(f"Jelenlegi pontszám: {pont}/{i+1}")

    print("\n====================")
    print("Vége a játéknak!")
    print(f"Pontszámod: {pont}/10")
    print("====================")

    return pont


# Menü
def menu():

    questions = load_questions("kerdesek.txt")

    while True:

        stats = load_stats("statisztika.txt")

        print("\n=== Földrajzi Kvíz - Főmenü ===")
        print("1. Játék indítása")
        print("2. Statisztika megtekintése")
        print("3. Kilépés")

        valasztas = input("Válassz egy opciót (1-3): ")

        # Játék indítása
        if valasztas == "1":

            pont = play_game(questions)

            save_stats("statisztika.txt", pont)

        # Statisztika
        elif valasztas == "2":

            print("\n=== STATISZTIKA ===")

            if len(stats) == 0:
                print("Még nincs mentett játék.")

            else:
                for i, pont in enumerate(stats, 1):
                    print(f"{i}. játék: {pont}/10")

                print(f"\nJátékok száma: {len(stats)}")
                print(f"Legjobb pontszám: {max(stats)}/10")
                print(f"Átlag pontszám: {round(sum(stats)/len(stats), 2)}")

        # Kilépés
        elif valasztas == "3":

            print("Viszlát!")
            break

        else:
            print("Érvénytelen választás, próbáld újra.")


# Program indítása
menu()